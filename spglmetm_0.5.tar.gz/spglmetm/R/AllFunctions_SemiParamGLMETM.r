##########################################################
### All functions for semi-param GLM based on ETM v0.5 ###
##########################################################
# ETM = exponentially tilted mixtures

### general functions
is.whole <- function(x,tol=.Machine$double.eps^0.5){
  return(abs(x-round(x)) < tol)
}
alr <- function(pi){ # maps (n-1)-Simplex to R^(n-1), length(pi) > 1
  return(log(pi[-length(pi)]/pi[length(pi)])) # last pi as reference
}
alrinv <- function(alrpi){ # maps R^(n-1) to (n-1)-Simplex
  alrpi <- ifelse(alrpi>400,400,alrpi) # otherwise explodes, 1 anyway
  pi <- exp(c(alrpi,0)) # last pi as reference
  return(pi/sum(pi)) # closure operation
}
link <- function(mu){log(mu)}
invlink <- function(eta){exp(eta)}
derivlink <- function(mu){1/mu}
rand.h.param.ini <- function(basis,y,m,seedval=NULL,tol=1e-4,fixed.weight=T){
  if (!is.null(seedval)){set.seed(seedval)}
  if (!fixed.weight){
    we <- alrinv(rnorm(m-1))
  } else {
    we <- rep(1/m,m)
  }
  if (basis=='gamma' | basis=='invgauss'){
    sh <- rchisq(n=1,df=3)
    me <- sort(runif(n=m,min=min(y)+tol,max=max(y)-tol))
    return(c(we,me,sh))
  } else {
    stop('Only "gamma" and "invgauss" basis supported so far.')
  }
}


### functions for gamma basis (E = mean, Var = mean^2/shape)
#  old param: (E = shape*scale, Var = shape*scale^2)
dETMgamma <- function(x,thetai,weight,mean,shape,log=FALSE){
  # scalar: x, thetai, shape; vector same length: weight, mean
  if (length(weight)!=length(mean)){
    stop('weight and mean must be of same length.')
  }
  if (length(shape)!=1 | shape<=0){stop('shape must be a positive scalar.')}
  if (length(x)!=1 | x<=0){stop('x must be a positive scalar.')}
  if (abs(sum(weight)-1)>1e-6){stop('weight should sum up to 1.')}
  if (any(thetai>=shape/mean)){stop('thetai out of range.')}
  mgf <- (1-mean*thetai/shape)^(-shape) # MGF of gamma basis
  if (log){
    return(as.numeric(thetai*x+
                        log(crossprod(weight,dGA(x=x,mean=mean,shape=shape)))-
                        log(crossprod(weight,mgf))))
  } else {
    return(as.numeric(exp(thetai*x)*
                        crossprod(weight,dGA(x=x,mean=mean,shape=shape))/
                        crossprod(weight,mgf)))
  }
}
pETMgamma <- function(q,thetai,weight,mean,shape){
  # scalar: q, thetai, shape; vector same length: weight, mean
  if (length(weight)!=length(mean)){
    stop('weight and mean must be of same length.')
  }
  if (length(shape)!=1 | shape<=0){stop('shape must be a positive scalar.')}
  if (length(q)!=1 | q<=0){stop('q must be a positive scalar.')}
  if (abs(sum(weight)-1)>1e-6){stop('weight should sum up to 1.')}
  if (any(thetai>=shape/mean)){stop('thetai out of range.')}
  mgf <- (1-mean*thetai/shape)^(-shape) # MGF of gamma basis
  incmgf <- mgf*pgamma(q=q*(shape/mean-thetai),shape=shape,scale=1) # inc. gamma
  return(as.numeric(crossprod(weight,incmgf)/crossprod(weight,mgf)))
}
qETMgamma <- function(p,thetai,weight,mean,shape,q.range=c(1e-20,1e50)){
  # scalar: p, thetai, shape; vector same length: weight, mean
  if (length(weight)!=length(mean)){
    stop('weight and mean must be of same length.')
  }
  if (length(shape)!=1 | shape<=0){stop('shape must be a positive scalar.')}
  if (length(p)!=1 | p>=1 | p<=0){stop('p must be a scalar within (0,1).')}
  if (abs(sum(weight)-1)>1e-6){stop('weight should sum up to 1.')}
  if (any(thetai>=shape/mean)){stop('thetai out of range.')}
  res <- uniroot(f=function(q,p,t,w,me,sh){pETMgamma(q,t,w,me,sh)-p},
                 interval=q.range,p=p,t=thetai,w=weight,me=mean,sh=shape)
  return(as.numeric(res$root))
}
rETMgamma <- function(n,theta,mu=NULL,weight,mean,shape,lb.t=-100,
                      q.range=c(1e-20,1e50),tol.t=1e-6,maxit.t=100){
  # scalar: n, shape; vector same length: weight, mean
  if (missing(theta)){
    if (is.null(mu)){
      stop('Either theta or mu must be supplied.')
    } else {
      theta <- getthetagamma(mu=mu,weight=weight,mean=mean,shape=shape,
                             lb=lb.t,ub=min(shape/mean)-tol.t,
                             tol=tol.t,maxit=maxit.t)
    }
  } else {
    if (any(theta>=shape/mean)){stop('theta out of range.')}
  }
  if (length(weight)!=length(mean)){
    stop('weight and mean must be of same length.')
  }
  if (length(shape)!=1 | shape<=0){stop('shape must be a positive scalar.')}
  if (!is.whole(n) | length(n)!=1 | n<=0){stop('n must be a positive integer.')}
  if (abs(sum(weight)-1)>1e-6){stop('weight should sum up to 1.')}
  uvec <- runif(n)
  if (length(theta)==1){
    return(vapply(X=uvec,FUN=qETMgamma,FUN.VALUE=numeric(1),
                  thetai=theta,weight=weight,mean=mean,shape=shape,
                  q.range=q.range))
  } else if (length(theta)==n){
    return(mapply(qETMgamma,uvec,theta,
                  MoreArgs=list(weight=weight,mean=mean,shape=shape,
                                q.range=q.range)))
  } else {stop('theta/mu must be either a scalar or a vector of length n.')}
}
# expecYigamma <- function(thetai,weight,scale,shape){
#   # scalar: thetai, shape; vector same length: weight, scale
#   # if (any(thetai>=1/scale)){stop('thetai out of range.')}
#   mgf.kern <- 1-scale*thetai
#   mgf <- mgf.kern^(-shape) # MGF of gamma basis
#   wj <- weight*mgf
#   wj <- wj/sum(wj) # divide by exp(b(thetai))
#   return(as.numeric(crossprod(wj,scale*shape/mgf.kern)))
# } # replaced by getthetagamma.cpp
varYigamma <- function(thetai,weight,mean,shape){
  # scalar: thetai, shape; vector same length: weight, mean
  mgf.kern <- (1-mean*thetai/shape)
  mgf <- mgf.kern^(-shape) # MGF of gamma basis
  wj <- weight*mgf
  wj <- wj/sum(wj) # divide by exp(b(thetai))
  expec <- crossprod(wj,mean/mgf.kern)
  expec2 <- crossprod(wj,mean^2/shape*(shape+1)/mgf.kern^2)
  return(as.numeric(expec2-expec^2))
}
# getthetagamma <- function(mui,weight,scale,shape,lb){
#   # scalar: mui, shape; vector same length: weight, scale
#   # theta.range: thetai < 1/scale
#   # lb: arbitrary lower bound (not too small)
#   theta.range <- c(lb,min(1/scale)-1e-8)
#   tryit <- try(uniroot(f=function(t,w,sc,sh,m){expecYigamma(t,w,sc,sh)-m},
#                        interval=theta.range,w=weight,sc=scale,sh=shape,m=mui),T)
#   if (class(tryit)!='try-error'){
#     return(tryit$root)
#   } else {
#     if (expecYigamma(0,weight,scale,shape)>mui){
#       return(theta.range[1]) # sol for theta arbitrarily small
#     } else {
#       return(theta.range[2]) # sol for theta arbitrarily large
#     }
#   }
# } # replaced by getthetagamma.cpp
loglikgamma <- function(y,mu,weight,mean,shape,theta=NULL,lb.t=-100,
                        tol.t=1e-6,maxit.t=100){
  # lb.t, tol.t and maxit.t set here and at betaIRWLSgamma
  if (length(y)!=length(mu)){stop('y and mu must be of same length.')}
  if (length(weight)!=length(mean)){
    stop('weight and mean must be of same length.')
  }
  if (length(shape)!=1 | shape<=0){stop('shape must be a positive scalar.')}
  if (any(mean<=0)){stop('mean must be positive.')}
  if (abs(sum(weight)-1)>1e-6){stop('weight should sum up to 1.')}
  if (is.null(theta)){
    theta <- getthetagamma(mu=mu,weight=weight,mean=mean,shape=shape,
                           lb=lb.t,ub=min(shape/mean)-tol.t,
                           tol=tol.t,maxit=maxit.t)
  }
  loglik <- mapply(FUN=dETMgamma,y,theta,
                   MoreArgs=list(weight=weight,mean=mean,shape=shape,log=T))
  return(as.numeric(sum(loglik)))
}
pnloglikgamma <- function(y,mu,weight,mean,shape,mubar,theta=NULL){
  # negative log-likelihood to minimize, no penalty anymore
  # return(as.numeric(-loglikgamma(y,mu,weight,mean,shape,theta)+
  #                     pen/2*(mubar-crossprod(weight,mean))^2))
  return(-loglikgamma(y,mu,weight,mean,shape,theta))
}
optweightgamma <- function(weight.ini,y,mu,mean,shape,mubar,meth='BFGS'){
  # meth set at optfgamma level
  opt <- optim(par=alr(weight.ini),fn=function(alrw,y,mu,me,sh,mub){
    pnloglikgamma(y=y,mu=mu,weight=alrinv(alrw),mean=me,shape=sh,mubar=mub)
  },
  method=meth,y=y,mu=mu,me=mean,sh=shape,mub=mubar)
  return(list('par'=alrinv(opt$par),'value'=opt$value))
}
# optmeangamma <- function(mean.ini,y,mu,weight,shape,mubar,pen,tol=1e-4,
#                           maxit=10){
#   m <- length(weight)
#   if (missing(mean.ini)){
#     me.out <- as.numeric(quantile(x=y,probs=(1:m)/(m+1)))
#   } else {
#     me.out <- mean.ini
#   }
#   # new version
#   ineq.mat <- rbind(matrix(c(-1,rep(0,m-2),1),nrow=m-1,ncol=m),
#                     c(rep(0,m-1),-1))
#   opt <- constrOptim(log(me.out),
#                      f=function(lme,y,mmu,we,sh,mub,pen){
#                        pnloglikgamma(y=y,mu=mmu,weight=we,mean=exp(lme),
#                                      shape=sh,mubar=mub,pen=pen)},
#                      ui=ineq.mat,ci=c(rep(0,m-1),-log(max(y))),
#                      method='Nelder-Mead',y=y,mmu=mu,we=weight,
#                      sh=shape,mub=mubar,pen=pen)
#   return(list('par'=exp(opt$par),'value'=opt$value))
# }
optmeangamma <- function(mean.ini,y,mu,weight,shape,mubar,tol=1e-4){
  # works only for weight = 1/m, otherwise ascending order of means can change
  m <- length(weight)
  if (is.null(mubar)){
    # new version, without pen and mubar
    ineq.mat <- rbind(matrix(c(-1,rep(0,m-2),1),nrow=m-1,ncol=m),
                      c(rep(0,m-1),-1))
    opt <- constrOptim(log(mean.ini),
                       f=function(lme,y,mmu,we,sh){
                         pnloglikgamma(y=y,mu=mmu,weight=we,
                                       mean=exp(lme),shape=sh)
                       },
                       ui=ineq.mat,ci=c(rep(0,m-1),-log(max(y))),
                       method='Nelder-Mead',y=y,mmu=mu,we=weight,sh=shape)
    res <- list('par'=exp(opt$par),'value'=opt$value)
  } else {
    # new new version, use alr for enforcing mubar constraint exactly
    if (m==2){ # then no inequality constraint after alr transform
      opt <- optimize(f=function(alrme,y,mmu,we,sh,mubar){
        pnloglikgamma(y=y,mu=mmu,weight=we,mean=alrinv(alrme)/we*mubar,shape=sh)
      },
      interval=c(-100,-tol), # neg guarantees ascending order
      y=y,mmu=mu,
      we=weight,sh=shape,mubar=mubar)
      res <- list('par'=alrinv(opt$min)/weight*mubar,'value'=opt$obj)
    } else {
      mestar <- weight*mean.ini/mubar # normalize to sum to 1
      ineq.mat <- matrix(c(-1,rep(0,m-3),1),nrow=m-2,ncol=m-1)
      opt <- constrOptim(theta=alr(mestar),
                         f=function(alrme,y,mmu,we,sh,mubar){
                           pnloglikgamma(y=y,mu=mmu,
                                         weight=we,
                                         mean=alrinv(alrme)/we*mubar,
                                         shape=sh)
                         },
                         ui=ineq.mat,ci=rep(0,m-2),
                         method='Nelder-Mead',y=y,mmu=mu,
                         we=weight,sh=shape,mubar=mubar)
      res <- list('par'=sort(alrinv(opt$par)/weight*mubar),'value'=opt$value)
      # sort harmless because weight=1/m, improve ascending order later
    }
  }
  return(res)
}
optshapegamma <- function(y,mu,weight,mean,mubar,shape.range=c(1e-4,100)){
  while(!is.finite(try(pnloglikgamma(y=y,mu=mu,weight=weight,mean=mean,
                                     shape=shape.range[2],mubar=mubar),T))){
    # shape.range <- c(shape.range[1],shape.range[2]/2)
    shape.range[2] <- shape.range[2]*0.9 # less crude than halving
  }
  opt <- optimize(f=function(sh,y,mu,we,me,mub){
    pnloglikgamma(y=y,mu=mu,weight=we,mean=me,shape=sh,mubar=mub)
  },y=y,mu=mu,we=weight,me=mean,mub=mubar,interval=shape.range)
  return(list('par'=opt$min,'value'=opt$obj))
}
optfgamma <- function(y,mu,weight,mean,shape,mubar,meth='BFGS',
                      tol=1e-4,maxit=10,shape.range=c(1e-4,100),fixed.weight){
  # meth set here
  # tol, maxit and shape.range set at flexglm level
  it <- 1
  pnl1 <- pnloglikgamma(y=y,mu=mu,weight=weight,mean=mean,shape=shape,
                        mubar=mubar)
  pnl0 <- pnl1+tol+1
  while(abs(pnl1-pnl0)>=tol & it<=maxit){
    pnl0 <- pnl1
    mean <- optmeangamma(mean.ini=mean,y=y,mu=mu,weight=weight,shape=shape,
                         mubar=mubar,tol=tol)$par
    if (!fixed.weight){
      weight <- optweightgamma(weight.ini=weight,y=y,mu=mu,mean=mean,shape=shape,
                               mubar=mubar,meth=meth)$par
    }
    opt <- optshapegamma(y=y,mu=mu,weight=weight,mean=mean,
                         mubar=mubar,shape.range=shape.range)
    shape <- opt$par
    pnl1 <- opt$value
    it <- it+1
  }
  return(list('weight'=weight,'mean'=mean,'shape'=shape,'value'=pnl1))
}
betaIRWLSgamma <- function(beta.ini,y,designX,weight,mean,shape,mubar,
                           tol,maxit,lb.t=-100,tol.t=1e-6,maxit.t=100){
  # lb.t, tol.t and maxit.t set here and at loglikgamma
  eta <- designX%*%beta.ini
  mu <- invlink(eta)
  theta <- getthetagamma(mu=mu,weight=weight,mean=mean,shape=shape,
                         lb=lb.t,ub=min(shape/mean)-tol.t,
                         tol=tol.t,maxit=maxit.t)
  pnl1 <- pnloglikgamma(y=y,mu=mu,weight=weight,mean=mean,shape=shape,
                        mubar=mubar,theta=theta)
  pnl0 <- pnl1+tol+1
  it <- 1
  while(abs(pnl1-pnl0)>tol & it<=maxit){
    pnl0 <- pnl1
    wi <- 1/((derivlink(mu))^2*
               vapply(X=theta,FUN=varYigamma,FUN.VALUE=numeric(1),
                      weight=weight,mean=mean,shape=shape))
    z <- eta+(y-mu)*derivlink(mu)
    wls <- lm(z~designX-1,weights=wi)
    beta <- coef(wls)
    eta <- fitted(wls)
    mu <- invlink(eta)
    theta <- getthetagamma(mu=mu,weight=weight,mean=mean,shape=shape,
                           lb=lb.t,ub=min(shape/mean)-tol.t,
                           tol=tol.t,maxit=maxit.t)
    pnl1 <- pnloglikgamma(y=y,mu=mu,weight=weight,mean=mean,shape=shape,
                          mubar=mubar,theta=theta)
    it <- it+1
  }
  return(list('beta'=beta,'mu'=mu,'theta'=theta,'pnl'=pnl1))
}
flexglm.gamma <- function(y,designX,m,altern=10,maxit=50,tol=1e-4,trace=TRUE,
                          h.param.ini=NULL,me.ini='quantile',fixed.weight=TRUE,
                          mubar=NULL,shape.range=c(1e-4,100)){
  # tol, maxit and shape.range set here
  # as of v0.5 fixed.weight=T now means fixed to 1/m
  #-----------------------------------------------------------------------------
  # Setup
  #-----------------------------------------------------------------------------
  if (!is.null(mubar) && !fixed.weight){
    stop('Non-null mubar only allowed if fixed.weight=TRUE.')
  }
  if (m<2){stop('Basis dimension m should be >= 2.')}
  y <- as.numeric(y)
  n <- length(y)
  onevec <- rep(1,n)
  designX <- as.matrix(designX)
  if (dim(designX)[1]!=n){stop('Length of y does not match nrows of designX.')}
  if (!identical(designX[,1],onevec)){designX <- cbind(onevec,designX)}
  p <- dim(designX)[2] # includes intercept
  #-----------------------------------------------------------------------------
  # Initial (weight,mean,shape) and beta
  #-----------------------------------------------------------------------------
  if (!is.null(h.param.ini)){
    warning('Make sure supplied h.param.ini is c(weight, mean, shape).')
    if (fixed.weight){
      we <- rep(1/m,m)
    } else {
      we <- h.param.ini[1:m]
    }
    me <- h.param.ini[(m+1):(2*m)]
    sh <- h.param.ini[2*m+1]
  } else {
    we <- rep(1/m,m) # as of v0.4 fixed if fixed.weight=T
    if (me.ini=='seq'){
      me <- seq(from=min(y)+1e-4,to=max(y)-1e-4,length.out=m)
    } else if (me.ini=='quantile'){
      me <- as.numeric(quantile(x=y,probs=(1:m)/(m+1))) # within range(y)
    } else {stop('Only "seq" and "quantile" are possible me.ini')}
    sh <- 1 # arbitrary but better than 1/summary(glmfit)$dispersion
  }
  glmfit <- try(glm(y~designX[,-1],family=Gamma(link='log')),T)
  if (all(class(glmfit)!='try-error')){
    beta <- glmfit$coef
    mu <- glmfit$fitted
    pnl1 <- pnloglikgamma(y=y,mu=mu,weight=we,mean=me,shape=sh,mubar=mubar)
  } else {
    estb <- betaIRWLSinvgauss(beta.ini=rep(0,p),designX=designX,
                              y=y,weight=we,mean=me,shape=sh,
                              mubar=mubar,tol=tol,maxit=maxit)
    beta <- estb$beta
    mu <- estb$mu
    pnl1 <- estb$pnl
  }
  if (trace){message('Initial neg. loglik = ',round(pnl1,5))}
  estf <- optfgamma(y=y,mu=mu,weight=we,mean=me,shape=sh,mubar=mubar,
                    tol=tol,maxit=maxit,fixed.weight=fixed.weight,
                    shape.range=shape.range)
  we <- estf$weight
  mean <- estf$mean
  sh <- estf$shape
  estb <- betaIRWLSgamma(beta.ini=beta,designX=designX,y=y,
                         weight=we,mean=me,shape=sh,mubar=mubar,
                         tol=tol,maxit=maxit)
  beta <- estb$beta
  mu <- estb$mu
  pnl1 <- estb$pnl
  if (trace){
    message('alt = 0: neg. loglik = ',round(pnl1,5))
    cat('h.param =',round(c(we,me,sh),3),'\n')
    cat('beta =',round(beta,3),'\n')
  }
  #-----------------------------------------------------------------------------
  # Alternate between beta and (weight,mean,shape)
  #-----------------------------------------------------------------------------
  alt <- 1
  pnl0 <- pnl1+tol+1
  while (alt<=altern & abs(pnl1-pnl0)>=tol){
    pnl0 <- pnl1
    estf <- optfgamma(y=y,mu=mu,weight=we,mean=me,shape=sh,mubar=mubar,
                      tol=tol,maxit=maxit,fixed.weight=fixed.weight,
                      shape.range=shape.range)
    we <- estf$weight
    me <- estf$mean
    sh <- estf$shape
    estb <- betaIRWLSgamma(beta.ini=beta,designX=designX,y=y,
                           weight=we,mean=me,shape=sh,mubar=mubar,
                           tol=tol,maxit=maxit)
    beta <- estb$beta
    mu <- estb$mu
    pnl1 <- estb$pnl
    if (trace){
      message('alt = ',alt,': neg. loglik = ',round(pnl1,5))
      cat('h.param =',round(c(we,me,sh),3),'\n')
      cat('beta =',round(beta,3),'\n')
    }
    alt <- alt+1
  }
  #-----------------------------------------------------------------------------
  # Output
  #-----------------------------------------------------------------------------
  theta <- estb$theta
  loglik <- loglikgamma(y,mu,we,me,sh,theta)
  var.y <- vapply(X=theta,FUN=varYigamma,FUN.VALUE=numeric(1),
                  weight=we,mean=me,shape=sh)
  wi <- as.numeric(1/((derivlink(mu))^2*var.y))
  std.err <- sqrt(diag(solve(t(designX)%*%diag(wi)%*%designX)))
  if (fixed.weight){
    if (is.null(mubar)){
      nparam <- p+m+1 # m means + 1 shape
    } else {
      nparam <- p+m # (m-1) means + 1 shape
    }
  } else {
    nparam <- p+2*m # (m-1) weights + m means + 1 shape
  }
  aic <- 2*(-loglik+nparam)
  aicc <- 2*(-loglik+nparam+nparam*(nparam+1)/(n-nparam-1))
  return(list('beta'=beta,'std.err.beta'=std.err,
              'fitted'=as.numeric(mu),'variance'=as.numeric(var.y),
              'theta'=theta,'neg.loglik'=pnl1,'loglik'=loglik,
              'aic'=aic,'aicc'=aicc,'y'=y,
              'h.param'=list('basis'='gamma',
                             'm'=m,'weight'=we,'mean'=me,'shape'=sh),
              'initial.glm'=glmfit))
}


### functions for IG basis (E = mean, Var = mean^3/shape)

# dIG <- function(x,mean,shape){ # faster than statmod::dinvgauss
#   return(sqrt(shape/2/pi/x^3)*exp(-shape/2/mean^2/x*(x-mean)^2))
# } # replaced by getthetainvgauss.cpp
dETMinvgauss <- function(x,thetai,weight,mean,shape,log=FALSE){
  # scalar: x, thetai, shape; vector same length: weight, mean
  if (length(weight)!=length(mean)){
    stop('weight and mean must be of same length.')
  }
  if (length(shape)!=1 | shape<=0){stop('shape must be a positive scalar.')}
  if (length(x)!=1 | x<=0){stop('x must be a positive scalar.')}
  if (abs(sum(weight)-1)>1e-6){stop('weight should sum up to 1.')}
  if (any(thetai>=shape/mean^2/2)){stop('thetai out of range.')}
  mgf <- exp(shape/mean*(1-sqrt(1-2*mean^2*thetai/shape))) # MGF of IG basis
  if (log){
    return(as.numeric(thetai*x+
                        log(crossprod(weight,dIG(x=x,mean=mean,shape=shape)))-
                        log(crossprod(weight,mgf))))
  } else {
    return(as.numeric(exp(thetai*x)*
                        crossprod(weight,dIG(x=x,mean=mean,shape=shape))/
                        crossprod(weight,mgf)))
  }
}
pETMinvgauss <- function(q,thetai,weight,mean,shape){
  # scalar: q, thetai, shape; vector same length: weight, mean
  if (length(weight)!=length(mean)){
    stop('weight and mean must be of same length.')
  }
  if (length(shape)!=1 | shape<=0){stop('shape must be a positive scalar.')}
  if (length(q)!=1 | q<=0){stop('q must be a positive scalar.')}
  if (abs(sum(weight)-1)>1e-6){stop('weight should sum up to 1.')}
  if (any(thetai>=shape/mean^2/2)){stop('thetai out of range.')}
  mgf.kern <- sqrt(1-2*mean^2*thetai/shape)
  mgf <- exp(shape/mean*(1-mgf.kern)) # MGF of IG basis
  # incmgf <- mgf*(1-exp(-q*(shape/(2*mean^2)-thetai))) # wrong from frmqa
  incmgf <- mgf*(pnorm(sqrt(shape/q)*(q*mgf.kern/mean-1))+ # incbesselK(nu=0.5)
                   exp(2*shape*mgf.kern/mean)*pnorm(-sqrt(shape/q)*(q*mgf.kern/mean+1)))
  return(as.numeric(crossprod(weight,incmgf)/crossprod(weight,mgf)))
}
qETMinvgauss <- function(p,thetai,weight,mean,shape,q.range=c(1e-20,1e50)){
  # scalar: p, thetai, shape; vector same length: weight, mean
  if (length(weight)!=length(mean)){
    stop('weight and mean must be of same length.')
  }
  if (length(shape)!=1 | shape<=0){stop('shape must be a positive scalar.')}
  if (length(p)!=1 | p>=1 | p<=0){stop('p must be a scalar within (0,1).')}
  if (abs(sum(weight)-1)>1e-6){stop('weight should sum up to 1.')}
  if (any(thetai>=shape/mean^2/2)){stop('thetai out of range.')}
  res <- uniroot(f=function(q,p,t,w,m,sh){pETMinvgauss(q,t,w,m,sh)-p},
                 interval=q.range,p=p,t=thetai,w=weight,m=mean,sh=shape)
  return(as.numeric(res$root))
}
rETMinvgauss <- function(n,theta,mu=NULL,weight,mean,shape,lb.t=-100,
                         q.range=c(1e-20,1e50),tol.t=1e-6,maxit.t=100){
  # scalar: n, shape; vector same length: weight, mean
  if (missing(theta)){
    if (is.null(mu)){
      stop('Either theta or mu must be supplied.')
    } else {
      theta <- getthetainvgauss(mu=mu,weight=weight,mean=mean,shape=shape,
                                lb=lb.t,ub=min(shape/mean^2/2)-tol.t,
                                tol=tol.t,maxit=maxit.t)
    }
  } else {
    if (any(theta>=min(shape/mean^2/2))){stop('theta out of range.')}
  }
  if (length(weight)!=length(mean)){
    stop('weight and mean must be of same length.')
  }
  if (length(shape)!=1 | shape<=0){stop('shape must be a positive scalar.')}
  if (!is.whole(n) | length(n)!=1 | n<=0){stop('n must be a positive integer.')}
  if (abs(sum(weight)-1)>1e-6){stop('weight should sum up to 1.')}
  uvec <- runif(n)
  if (length(theta)==1){
    return(vapply(X=uvec,FUN=qETMinvgauss,FUN.VALUE=numeric(1),
                  thetai=theta,weight=weight,mean=mean,shape=shape,
                  q.range=q.range))
  } else if (length(theta)==n){
    return(mapply(qETMinvgauss,uvec,theta,
                  MoreArgs=list(weight=weight,mean=mean,shape=shape,
                                q.range=q.range)))
  } else {stop('theta/mu must be either a scalar or a vector of length n.')}
}
# expecYiinvgauss <- function(thetai,weight,mean,shape){
#   # scalar: thetai, shape; vector same length: weight, mean
#   # if (any(thetai>=shape/mean^2/2)){stop('thetai out of range.')}
#   mgf.kern <- sqrt(1-2*mean^2*thetai/shape)
#   mgf <- exp(shape/mean*(1-mgf.kern)) # MGF of IG basis
#   wj <- weight*mgf
#   wj <- wj/sum(wj) # divide by exp(b(thetai))
#   return(as.numeric(crossprod(wj,mean/mgf.kern)))
# } # replaced by getthetainvgauss.cpp
varYiinvgauss <- function(thetai,weight,mean,shape){
  # scalar: thetai, shape; vector same length: weight, mean
  # if (any(thetai>=shape/mean^2/2)){stop('thetai out of range.')}
  mgf.kern <- sqrt(1-2*mean^2*thetai/shape)
  mgf <- exp(shape/mean*(1-mgf.kern)) # MGF of IG basis
  wj <- weight*mgf
  wj <- wj/sum(wj) # divide by exp(b(thetai))
  expec <- crossprod(wj,mean/mgf.kern)
  expec2 <- crossprod(wj,mean^2*(mgf.kern+mean/shape)/mgf.kern^3)
  return(as.numeric(expec2-expec^2))
}
# getthetainvgauss <- function(mui,weight,mean,shape,lb=-10){
#   # scalar: mui, shape; vector same length: weight, mean
#   # theta.range: thetai < shape/mean^2/2
#   # lower bound = lb = -10 (arbitrary)
#   theta.range <- c(lb,min(shape/mean^2/2)-1e-8)
#   tryit <- try(uniroot(f=function(t,w,me,sh,m){expecYiinvgauss(t,w,me,sh)-m},
#                        interval=theta.range,w=weight,me=mean,sh=shape,m=mui),T)
#   if (class(tryit)!='try-error'){
#     return(tryit$root)
#   } else {
#     if (expecYiinvgauss(0,weight,mean,shape)>mui){
#       return(theta.range[1]) # sol for theta arbitrarily small
#     } else {
#       return(theta.range[2]) # sol for theta arbitrarily large
#     }
#   }
# } # replaced by getthetainvgauss.cpp
loglikinvgauss <- function(y,mu,weight,mean,shape,theta=NULL,lb.t=-100,
                           tol.t=1e-6,maxit.t=100){
  # lb.t, tol.t and maxit.t set here and at betaIRWLSinvgauss
  if (length(y)!=length(mu)){
    stop('y and mu must be of same length.')
  }
  if (length(weight)!=length(mean)){
    stop('weight and mean must be of same length.')
  }
  if (length(shape)!=1 | shape<=0){stop('shape must be a positive scalar.')}
  if (any(mean<=0)){stop('mean must be positive.')}
  if (abs(sum(weight)-1)>1e-6){stop('weight should sum up to 1.')}
  if (is.null(theta)){
    theta <- getthetainvgauss(mu=mu,weight=weight,mean=mean,shape=shape,
                              lb=lb.t,ub=min(shape/mean^2/2)-tol.t,
                              tol=tol.t,maxit=maxit.t)
  }
  loglik <- mapply(FUN=dETMinvgauss,y,theta,
                   MoreArgs=list(weight=weight,mean=mean,shape=shape,log=T))
  return(as.numeric(sum(loglik)))
}
pnloglikinvgauss <- function(y,mu,weight,mean,shape,mubar,theta=NULL){
  # negative log-likelihood to minimize, no penalty anymore
  # return(as.numeric(-loglikinvgauss(y,mu,weight,mean,shape,theta)+
  #                     pen/2*(mubar-crossprod(weight,mean))^2))
  return(-loglikinvgauss(y,mu,weight,mean,shape,theta))
}
optweightinvgauss <- function(weight.ini,y,mu,mean,shape,mubar,meth='BFGS'){
  # meth set at optfinvgauss level
  # no missing(weight.ini) because only called from optfinvgauss
  opt <- optim(par=alr(weight.ini),fn=function(alrw,y,mu,me,sh,mub){
    pnloglikinvgauss(y=y,mu=mu,weight=alrinv(alrw),mean=me,shape=sh,
                     mubar=mub)
  },
  method=meth,y=y,mu=mu,me=mean,sh=shape,mub=mubar)
  return(list('par'=alrinv(opt$par),'value'=opt$value))
}
optmeaninvgauss <- function(mean.ini,y,mu,weight,shape,mubar,tol=1e-4){
  # works only for weight = 1/m, otherwise ascending order of means can change
  m <- length(weight)
  if (is.null(mubar)){
    # new version, without pen and mubar
    ineq.mat <- rbind(matrix(c(-1,rep(0,m-2),1),nrow=m-1,ncol=m),
                      c(rep(0,m-1),-1))
    opt <- constrOptim(log(mean.ini),
                       f=function(lme,y,mmu,we,sh){
                         pnloglikinvgauss(y=y,mu=mmu,weight=we,
                                          mean=exp(lme),shape=sh)
                       },
                       ui=ineq.mat,ci=c(rep(0,m-1),-log(max(y))),
                       method='Nelder-Mead',y=y,mmu=mu,we=weight,sh=shape)
    res <- list('par'=exp(opt$par),'value'=opt$value)
  } else {
    # new new version, use alr for enforcing mubar constraint exactly
    if (m==2){ # then no inequality constraint after alr transform
      opt <- optimize(f=function(alrme,y,mmu,we,sh,mubar){
        pnloglikinvgauss(y=y,mu=mmu,weight=we,
                         mean=alrinv(alrme)/we*mubar,shape=sh)
      },
      interval=c(-100,-tol), # neg guarantees ascending order
      y=y,mmu=mu,
      we=weight,sh=shape,mubar=mubar)
      res <- list('par'=alrinv(opt$min)/weight*mubar,'value'=opt$obj)
    } else {
      mestar <- weight*mean.ini/mubar # normalize to sum to 1
      ineq.mat <- matrix(c(-1,rep(0,m-3),1),nrow=m-2,ncol=m-1)
      opt <- constrOptim(theta=alr(mestar),
                         f=function(alrme,y,mmu,we,sh,mubar){
                           pnloglikinvgauss(y=y,mu=mmu,
                                            weight=we,
                                            mean=alrinv(alrme)/we*mubar,
                                            shape=sh)
                         },
                         ui=ineq.mat,ci=rep(0,m-2),
                         method='Nelder-Mead',y=y,mmu=mu,
                         we=weight,sh=shape,mubar=mubar)
      res <- list('par'=sort(alrinv(opt$par)/weight*mubar),'value'=opt$value)
      # sort harmless because weight=1/m, improve ascending order later
    }
  }
  return(res)
}
# optmeaninvgauss <- function(mean.ini,y,mu,weight,shape,mubar,pen){
#   m <- length(weight)
#   if (missing(mean.ini)){
#     # me.out <- as.numeric(quantile(x=y,probs=(1:m)/(m+1)))
#     # me.out <- as.numeric(c(min(y)+1e-4,
#     #                        quantile(x=y,probs=(1:(m-2))/(m-1)),
#     #                        max(y)-1e-4))
#     me.out <- seq(from=min(y)+1e-4,to=max(y)-1e-4,length.out=m)
#   } else {
#     me.out <- mean.ini
#   }
#   # new version
#   ineq.mat <- rbind(matrix(c(-1,rep(0,m-2),1),nrow=m-1,ncol=m),
#                     c(rep(0,m-1),-1))
#   opt <- constrOptim(log(me.out),
#                      f=function(lme,y,mmu,we,sh,mub,pen){
#                        pnloglikinvgauss(y=y,mu=mmu,weight=we,mean=exp(lme),
#                                         shape=sh,mubar=mub,pen=pen)},
#                      ui=ineq.mat,ci=c(rep(0,m-1),-log(max(y))),
#                      method='Nelder-Mead',y=y,mmu=mu,we=weight,
#                      sh=shape,mub=mubar,pen=pen)
#   return(list('par'=exp(opt$par),'value'=opt$value))
# }
optshapeinvgauss <- function(y,mu,weight,mean,mubar,shape.range=c(1e-4,100)){
  while(!is.finite(try(pnloglikinvgauss(y=y,mu=mu,weight=weight,mean=mean,
                                        shape=shape.range[2],mubar=mubar),T))){
    shape.range <- c(shape.range[1],shape.range[2]/2)
  }
  opt <- optimize(f=function(sh,y,mu,we,me,mub){
    pnloglikinvgauss(y=y,mu=mu,weight=we,mean=me,shape=sh,mubar=mub)
  },
  y=y,mu=mu,we=weight,me=mean,mub=mubar,interval=shape.range)
  return(list('par'=opt$min,'value'=opt$obj))
}
optfinvgauss <- function(y,mu,weight,mean,shape,mubar,meth='BFGS',
                         tol=1e-4,maxit=10,shape.range=c(1e-4,100),
                         fixed.weight){
  # meth set here
  # shape.range, tol and maxit set at flexglm level
  it <- 1
  pnl1 <- pnloglikinvgauss(y=y,mu=mu,weight=weight,mean=mean,shape=shape,
                           mubar=mubar)
  pnl0 <- pnl1+tol+1
  while(abs(pnl1-pnl0)>=tol & it<=maxit){
    pnl0 <- pnl1
    mean <- optmeaninvgauss(mean.ini=mean,y=y,mu=mu,weight=weight,shape=shape,
                            mubar=mubar,tol=tol)$par
    if (!fixed.weight){
      weight <- optweightinvgauss(weight.ini=weight,y=y,mu=mu,mean=mean,
                                  shape=shape,mubar=mubar,meth=meth)$par
    }
    opt <- optshapeinvgauss(y=y,mu=mu,weight=weight,mean=mean,
                            mubar=mubar,shape.range=shape.range)
    shape <- opt$par
    pnl1 <- opt$value
    it <- it+1
  }
  return(list('weight'=weight,'mean'=mean,'shape'=shape,'value'=pnl1))
}
betaIRWLSinvgauss <- function(beta.ini,y,designX,weight,mean,shape,mubar,
                              tol,maxit,lb.t=-100,tol.t=1e-6,maxit.t=100){
  # lb.t, tol.t and maxit.t set here and at loglikinvgauss
  eta <- designX%*%beta.ini
  mu <- invlink(eta)
  theta <- getthetainvgauss(mu=mu,weight=weight,mean=mean,shape=shape,
                            lb=lb.t,ub=min(shape/mean^2/2)-tol.t,
                            tol=tol.t,maxit=maxit.t)
  pnl1 <- pnloglikinvgauss(y=y,mu=mu,weight=weight,mean=mean,shape=shape,
                           mubar=mubar,theta=theta)
  pnl0 <- pnl1+tol+1
  it <- 1
  while(abs(pnl1-pnl0)>tol & it<=maxit){
    pnl0 <- pnl1
    wi <- 1/((derivlink(mu))^2*
               vapply(X=theta,FUN=varYiinvgauss,FUN.VALUE=numeric(1),
                      weight=weight,mean=mean,shape=shape))
    z <- eta+(y-mu)*derivlink(mu)
    wls <- lm(z~designX-1,weights=wi)
    beta <- coef(wls)
    eta <- fitted(wls)
    mu <- invlink(eta)
    theta <- getthetainvgauss(mu=mu,weight=weight,mean=mean,shape=shape,
                              lb=lb.t,ub=min(shape/mean^2/2)-tol.t,
                              tol=tol.t,maxit=maxit.t)
    pnl1 <- pnloglikinvgauss(y=y,mu=mu,weight=weight,mean=mean,shape=shape,
                             mubar=mubar,theta=theta)
    it <- it+1
  }
  return(list('beta'=beta,'mu'=mu,'theta'=theta,'pnl'=pnl1))
}
flexglm.invgauss <- function(y,designX,m,altern=10,maxit=50,tol=1e-4,trace=TRUE,
                             h.param.ini=NULL,me.ini='quantile',fixed.weight=TRUE,
                             mubar=NULL,shape.range=c(1e-4,100)){
  # tol, maxit and shape.range set here
  #-----------------------------------------------------------------------------
  # Setup
  #-----------------------------------------------------------------------------
  if (!is.null(mubar) && !fixed.weight){
    stop('Non-null mubar only allowed if fixed.weight=TRUE.')
  }
  if (m<2){stop('Basis dimension m should be >= 2.')}
  y <- as.numeric(y)
  n <- length(y)
  onevec <- rep(1,n)
  designX <- as.matrix(designX)
  if (dim(designX)[1]!=n){stop('Length of y does not match nrows of designX.')}
  if (!identical(designX[,1],onevec)){designX <- cbind(onevec,designX)}
  p <- dim(designX)[2] # includes intercept
  #-----------------------------------------------------------------------------
  # Initial (weight,mean,shape) and beta
  #-----------------------------------------------------------------------------
  if (!is.null(h.param.ini)){
    warning('Make sure supplied h.param.ini is c(weight, mean, shape).')
    if (fixed.weight){
      we <- rep(1/m,m)
    } else {
      we <- h.param.ini[1:m]
    }
    me <- h.param.ini[(m+1):(2*m)]
    sh <- h.param.ini[2*m+1]
  } else {
    we <- rep(1/m,m) # as of v0.4 fixed if fixed.weight=T
    if (me.ini=='seq'){
      me <- seq(from=min(y)+1e-4,to=max(y)-1e-4,length.out=m)
    } else if (me.ini=='quantile'){
      me <- as.numeric(quantile(x=y,probs=(1:m)/(m+1))) # within range(y)
    } else {stop('Only "seq" and "quantile" are possible me.ini')}
    sh <- 1 # arbitrary but better than 2/summary(glmfit)$dispersion
  }
  glmfit <- try(glm(y~designX[,-1],family=inverse.gaussian(link='log')),T)
  if (all(class(glmfit)!='try-error')){
    beta <- glmfit$coef
    mu <- glmfit$fitted
    pnl1 <- pnloglikinvgauss(y=y,mu=mu,weight=we,mean=me,shape=sh,mubar=mubar)
  } else {
    estb <- betaIRWLSinvgauss(beta.ini=rep(0,p),designX=designX,
                              y=y,weight=we,mean=me,shape=sh,
                              mubar=mubar,tol=tol,maxit=maxit)
    beta <- estb$beta
    mu <- estb$mu
    pnl1 <- estb$pnl
  }
  if (trace){message('Initial neg. loglik = ',round(pnl1,5))}
  estf <- optfinvgauss(y=y,mu=mu,weight=we,mean=me,shape=sh,mubar=mubar,
                       fixed.weight=fixed.weight,tol=tol,maxit=maxit,
                       shape.range=shape.range)
  we <- estf$weight
  me <- estf$mean
  sh <- estf$shape
  estb <- betaIRWLSinvgauss(beta.ini=beta,designX=designX,y=y,
                            weight=we,mean=me,shape=sh,mubar=mubar,
                            tol=tol,maxit=maxit)
  beta <- estb$beta
  mu <- estb$mu
  pnl1 <- estb$pnl
  if (trace){
    message('alt = 0: neg. loglik = ',round(pnl1,5))
    cat('h.param =',round(c(we,me,sh),3),'\n')
    cat('beta =',round(beta,3),'\n')
  }
  #-----------------------------------------------------------------------------
  # Alternate between beta and (weight,mean,shape)
  #-----------------------------------------------------------------------------
  alt <- 1
  pnl0 <- pnl1+tol+1
  while (alt<=altern & abs(pnl1-pnl0)>=tol){
    pnl0 <- pnl1
    estf <- optfinvgauss(y=y,mu=mu,weight=we,mean=me,shape=sh,mubar=mubar,
                         fixed.weight=fixed.weight,tol=tol,maxit=maxit,
                         shape.range=shape.range)
    we <- estf$weight
    me <- estf$mean
    sh <- estf$shape
    estb <- betaIRWLSinvgauss(beta.ini=beta,designX=designX,y=y,
                              weight=we,mean=me,shape=sh,mubar=mubar,
                              tol=tol,maxit=maxit)
    beta <- estb$beta
    mu <- estb$mu
    pnl1 <- estb$pnl
    if (trace){
      message('alt = ',alt,': neg. loglik = ',round(pnl1,5))
      cat('h.param =',round(c(we,me,sh),3),'\n')
      cat('beta =',round(beta,3),'\n')
    }
    alt <- alt+1
  }
  #-----------------------------------------------------------------------------
  # Output
  #-----------------------------------------------------------------------------
  theta <- estb$theta
  loglik <- loglikinvgauss(y,mu,we,me,sh,theta)
  var.y <- vapply(X=theta,FUN=varYiinvgauss,FUN.VALUE=numeric(1),
                  weight=we,mean=me,shape=sh)
  wi <- as.numeric(1/((derivlink(mu))^2*var.y))
  std.err <- sqrt(diag(solve(t(designX)%*%diag(wi)%*%designX)))
  if (fixed.weight){
    if (is.null(mubar)){
      nparam <- p+m+1 # m means + 1 shape
    } else {
      nparam <- p+m # (m-1) means + 1 shape
    }
  } else {
    nparam <- p+2*m # (m-1) weights + m means + 1 shape
  }
  aic <- 2*(-loglik+nparam)
  aicc <- 2*(-loglik+nparam+nparam*(nparam+1)/(n-nparam-1))
  return(list('beta'=beta,'std.err.beta'=std.err,
              'fitted'=as.numeric(mu),'variance'=as.numeric(var.y),
              'theta'=theta,'aic'=aic,'aicc'=aicc,'y'=y,
              'neg.loglik'=pnl1,'loglik'=loglik,
              'h.param'=list('basis'='invgauss',
                             'm'=m,'weight'=we,'mean'=me,'shape'=sh),
              'initial.glm'=glmfit))
}

### common to all basis, to document
h.predict <- function(flexglmobj,y.grid=NULL,mubar=NULL){
  # mubar used for standardizing baseline, if missing then theta=0
  y <- flexglmobj$y
  if (is.null(y.grid)){
    y.grid <- seq(min(y),max(y),length.out=200)
  }
  we <- flexglmobj$h.param$weight
  me <- flexglmobj$h.param$mean
  sh <- flexglmobj$h.param$shape
  if (flexglmobj$h.param$basis=='invgauss'){
    if (is.null(mubar)){
      theta <- 0
    } else {
      theta <- getthetainvgauss(mu=mubar,weight=we,mean=me,shape=sh,lb=-100,
                                ub=min(sh/me^2/2)-1e-6,tol=1e-6,maxit=100)
    }
    fhat <- vapply(X=y.grid,FUN=dETMinvgauss,FUN.VALUE=numeric(1),
                   thetai=theta,weight=we,mean=me,shape=sh)
    Fhat <- vapply(X=y.grid,FUN=pETMinvgauss,FUN.VALUE=numeric(1),
                   thetai=theta,weight=we,mean=me,shape=sh)
  } else if (flexglmobj$h.param$basis=='gamma'){
    if (is.null(mubar)){
      theta <- 0
    } else {
      theta <- getthetagamma(mu=mubar,weight=we,mean=me,shape=sh,lb=-100,
                             ub=min(sh/me)-1e-6,tol=1e-6,maxit=100)
    }
    fhat <- vapply(X=y.grid,FUN=dETMgamma,FUN.VALUE=numeric(1),
                   thetai=theta,weight=we,mean=me,shape=sh)
    Fhat <- vapply(X=y.grid,FUN=pETMgamma,FUN.VALUE=numeric(1),
                   thetai=theta,weight=we,mean=me,shape=sh)
  }
  return(list('y.grid'=y.grid,'h.pdf'=fhat,'h.cdf'=Fhat,'theta'=theta))
}
# END
