#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
NumericVector dIG(
	double x,
	NumericVector mean,
	double shape
	)
{
	// const double PI = 3.141592653589793238463;
	int m = mean.size();
	NumericVector res(m);
	for (int j=0; j<m; ++j){
		res[j] = exp(-shape/(2.0*pow(mean[j],2)*x)*pow((x-mean[j]),2));
	}
	res = res*sqrt(shape/(2.0*M_PI*pow(x,3))); // faster than in v0.4
	return res;
}

// [[Rcpp::export]]
double expecYiinvgauss(
	double thetai,
	NumericVector weight,
	NumericVector mean,
	double shape
	)
{
	int m = weight.size();
	double out = 0.0;
	double sumwj = 0.0;
	NumericVector mgfkern = sqrt(1.0-2.0*pow(mean,2)*thetai/shape); // kernel of MGF
	NumericVector wj = weight*exp(shape/mean*(1.0-mgfkern)); // weight*MGF
	for (int i=0; i<m; ++i){
		out += wj[i]*mean[i]/mgfkern[i];
		sumwj += wj[i];
	}
	return out/sumwj;
}

// [[Rcpp::export]]
double thetabisectinvgauss(
	double mui,
	NumericVector weight,
	NumericVector mean,
	double shape,
	double lb,
	double ub,
	double tol,
	int maxit
	)
{
	double flb = expecYiinvgauss(lb, weight, mean, shape)-mui;
	double fub = expecYiinvgauss(ub, weight, mean, shape)-mui;
	double absdiff = fabs(fub-flb);
	double root;
	// check bounds
	if (flb > 0.0){
		root = lb;
	} else if (fub < 0.0){
		root = ub;
	} else {
		// test if either endpoint is a root or if bounds have same height
		if (fabs(flb) < tol){
			root = lb;
		} else if (fabs(fub) < tol){
			root = ub;
		} else if (absdiff < tol){
			root = lb; // arbitrary, function is constant if monotone
		} else {
			// main loop: bisection, exit when c good enough
			double c;
		  double fc;
			int it = 0;
			while (it<maxit && absdiff>tol){
				c = (lb+ub)/2.0;
				fc = expecYiinvgauss(c, weight, mean, shape)-mui;
				if (fabs(fc) < tol){
					root = c;
					absdiff = tol;
				} else if (fc > 0.0){
					ub = c;
					fub = fc;
				} else if (fc < 0.0){
					lb = c;
					flb = fc;
				}
				it++;
			}
			if (it == maxit){
				root = lb; // to improve later
			}
		}
	}
	return root;
}

// [[Rcpp::export]]
NumericVector getthetainvgauss(
	NumericVector mu,
	NumericVector weight,
	NumericVector mean,
	double shape,
	double lb,
	double ub,
	double tol,
	int maxit
	)
{
	int n = mu.size();
	NumericVector res(n);
	for (int i=0; i<n; ++i){
		res[i] = thetabisectinvgauss(mu[i], weight, mean, shape, lb, ub, tol, maxit);
	}
	return res;
}
