#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
NumericVector dGA(
	double x,
	NumericVector mean,
	double shape
	)
{
	int m = mean.size();
	NumericVector res(m);
	double shapex = x*shape;
	for (int j=0; j<m; ++j){
	res[j] = exp(-shapex/mean[j]-shape*log(mean[j]));
	}
	res = res*pow(shapex,shape)/(tgamma(shape)*x);
	return res;
}

// [[Rcpp::export]]
double expecYigamma(
	double thetai,
	NumericVector weight,
	NumericVector mean,
	double shape
	)
{
	int m = weight.size();
	double out = 0.0;
	double sumwj = 0.0;
	NumericVector mgfkern = 1.0-mean*thetai/shape; // kernel of gamma MGF
	NumericVector wj = weight*pow(mgfkern,-shape); // weight*MGF
	for (int i=0; i<m; ++i){
		out += wj[i]*mean[i]/mgfkern[i];
		sumwj += wj[i];
	}
	return out/sumwj;
}

// varYi not slower in R, not worth it here
/*
// [[Rcpp::export]]
double varYigamma(
	double thetai,
	NumericVector weight,
	NumericVector mean,
	double shape
	)
{
	int m = weight.size();
	double out = 0.0;
	double out2 = 0.0;
	double sumwj = 0.0;
	NumericVector mgfkern = 1.0-mean*thetai/shape; // kernel of gamma MGF
	NumericVector wj = weight*pow(mgfkern,-shape); // weight*MGF
	double shape1shape = (shape+1.0)/shape;
	for (int i=0; i<m; ++i){
		out += wj[i]*mean[i]/mgfkern[i];
		out2 += wj[i]*pow(mean[i]/mgfkern[i],2);
		sumwj += wj[i];
	}
	return out2*shape1shape/sumwj-pow(out/sumwj,2);
}
*/

// [[Rcpp::export]]
double thetabisectgamma(
	double mui,
	NumericVector weight,
	NumericVector mean,
	double shape,
	double lb,
	double ub,
	double tol,
	int maxit
	)
{
	double flb = expecYigamma(lb, weight, mean, shape)-mui;
	double fub = expecYigamma(ub, weight, mean, shape)-mui;
	double absdiff = fabs(fub-flb);
	double root;
	// check bounds
	if (flb > 0.0){
		root = lb;
	} else if (fub < 0.0){
		root = ub;
	} else {
		// test if either endpoint is a root or if bounds have same height
		if (fabs(flb) < tol){
			root = lb;
		} else if (fabs(fub) < tol){
			root = ub;
		} else if (absdiff < tol){
			root = lb; // arbitrary, function is constant if monotone
		} else {
			// main loop: bisection, exit when c good enough
			double c;
		  double fc;
			int it = 0;
			while (it<maxit && absdiff>tol){
				c = (lb+ub)/2.0;
				fc = expecYigamma(c, weight, mean, shape)-mui;
				if (fabs(fc) < tol){
					root = c;
					absdiff = tol;
				} else if (fc > 0.0){
					ub = c;
					fub = fc;
				} else if (fc < 0.0){
					lb = c;
					flb = fc;
				}
				it++;
			}
			if (it == maxit){
				root = lb; // to improve later
			}
		}
	}
	return root;
}

// [[Rcpp::export]]
NumericVector getthetagamma(
	NumericVector mu,
	NumericVector weight,
	NumericVector mean,
	double shape,
	double lb,
	double ub,
	double tol,
	int maxit
	)
{
	int n = mu.size();
	NumericVector res(n);
	for (int i=0; i<n; ++i){
		res[i] = thetabisectgamma(mu[i], weight, mean, shape, lb, ub, tol, maxit);
	}
	return res;
}
